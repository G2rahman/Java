
package OOP;

public class Student extends Person {

	public Student(String name, int age) {
		super(name, age);
	}
	
	
}