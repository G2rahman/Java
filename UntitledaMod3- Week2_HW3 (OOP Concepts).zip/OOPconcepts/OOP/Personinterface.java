package OOP;

public interface PersonInterface {
	
	static final String organization = "Codingcamp";
	

	
	public String printMsg(String msg);
	
	
	
}