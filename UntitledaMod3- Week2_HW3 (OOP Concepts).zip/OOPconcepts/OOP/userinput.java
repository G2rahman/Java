package OOP;
import java.util.Scanner;

public class userinput {

	public static void String[] args) {
		System.out.println("Enter employee's name:");
		String employeeName = scan.nextLine();
		System.out.println("Enter employee's age:");
		int employeeAge=scan.NextInt();
		
		scan.nextLine();
		
		Systemout.println("Enter student's name:");
		String studentName=scan.nextLine();
		Systemout.println("Enter student's age:");
		Int studentAge=scan.nextLine();
		
		Employee employee1 = new Employee(employeeName, employeeAge);
		Student student1 = new Student (studentName, studentAge);
		
		Person1 firstPerson = new Person1();
		
		firstPerson.setAge(34);
		firstPerson.setName("Billy");
		
		System.out.println(firstPerson.getAge());
		System.out.println(firstPerson.getName());
	}
}
